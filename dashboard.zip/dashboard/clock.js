window.onload=setInterval(function(){
	ora();
},1000);

function ora(){
	var datumido = new Date();
	var h = korrektor(datumido.getHours());
	var m = korrektor(datumido.getMinutes());

	document.getElementsByTagName("h1")[0].innerHTML = ".:"+h+":"+m+":.";
}

function korrektor (t){
	if(t<10){
		t="0"+t;
	}
	return t;
}

